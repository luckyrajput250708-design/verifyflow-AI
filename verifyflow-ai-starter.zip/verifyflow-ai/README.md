# VerifyFlow AI

**Verify supplier documents and flag discrepancies for human review.**

VerifyFlow AI is an early-stage student project that aims to help small distributors and wholesalers compare purchase orders, supplier invoices, and delivery receipts. It highlights possible differences in quantities, unit prices, and totals so a person can review them before taking action.

> **Project status:** Prototype / under development  
> **Important:** VerifyFlow AI is decision support, not an accounting system or an autonomous payment/fraud-decision tool. All flagged discrepancies require human verification.

## Problem

Small businesses may compare purchase orders, invoices, and delivery records manually. Differences in quantities, prices, item descriptions, or duplicate invoice numbers can take time to find. The first goal is to test whether a lightweight tool can make these checks faster and easier.

## Initial MVP

- Accept synthetic or approved sample document data.
- Normalize product descriptions and units.
- Compare quantities, unit prices, and line totals.
- Flag potential discrepancies with an explanation.
- Export a simple report for human review.

The first prototype will use structured sample data before adding PDF/image OCR.

## Planned technology

- Python
- Streamlit
- Pandas
- RapidFuzz (for approximate item-name matching)
- Pytest (for automated tests)
- PyMuPDF / Tesseract OCR (planned document extraction)

## Run locally

1. Install Python 3.10 or newer.
2. Clone this repository:
   ```bash
   git clone https://github.com/YOUR-USERNAME/verifyflow-ai.git
   cd verifyflow-ai
   ```
3. Create and activate a virtual environment:
   ```bash
   python -m venv .venv
   ```
4. Install dependencies:
   ```bash
   # Windows
   .venv\\Scripts\\activate

   # macOS/Linux
   source .venv/bin/activate

   pip install -r requirements.txt
   ```
5. Start the app:
   ```bash
   streamlit run app.py
   ```

## Roadmap

1. Validate the workflow with small businesses.
2. Build structured-data comparison and discrepancy rules.
3. Add tests and an evaluation dataset.
4. Add document extraction for PDFs and scans.
5. Run a small, permission-based pilot and measure time saved and error rates.

## Data and privacy

Use synthetic examples for development. Do not commit customer invoices, purchase orders, credentials, API keys, or other confidential information. Obtain permission before processing real business documents and define a retention/deletion process.

## Contributing

For a student project, contributions can begin with bug reports, test cases, documentation, and small pull requests. Discuss major changes before implementing them.

## License

No license has been selected yet. Until a license is added, assume that normal copyright applies and reuse is not automatically permitted.
